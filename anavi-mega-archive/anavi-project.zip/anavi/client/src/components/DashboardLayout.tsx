import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import { 
  LayoutDashboard, LogOut, PanelLeft, Users, Target, Handshake, 
  TrendingUp, FolderLock, Shield, DollarSign, Network, Settings,
  Landmark, Crosshair, Calendar, BarChart3,
  Building2, Wallet, History, Briefcase, Gem, Home, Zap, Lock, BookOpen, Send, Brain, Coins, Sparkles
} from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Brain, label: "Deal Intelligence", path: "/deal-intelligence", highlight: true },
  { icon: Sparkles, label: "AI Brain", path: "/ai-brain", highlight: true },
  { icon: Network, label: "Knowledge Graph", path: "/knowledge-graph", highlight: true },
  { icon: Lock, label: "Deal Room", path: "/deal-room", highlight: true },
  { icon: BookOpen, label: "Manifesto", path: "/manifesto" },
  { icon: Send, label: "Submit Deal", path: "/operator-intake" },
  { icon: BarChart3, label: "Analytics", path: "/analytics" },
  { icon: Calendar, label: "Calendar", path: "/calendar" },
  { icon: Building2, label: "SPV Generator", path: "/spv-generator" },
  { icon: Briefcase, label: "LP Portal", path: "/lp-portal" },
  { icon: Wallet, label: "Capital Management", path: "/capital-management" },
  { icon: Landmark, label: "Family Offices", path: "/family-offices" },
  { icon: Crosshair, label: "Targeting", path: "/targeting" },
  { icon: Users, label: "Relationships", path: "/relationships" },
  { icon: Target, label: "Intents", path: "/intents" },
  { icon: Handshake, label: "Matches", path: "/matches" },
  { icon: TrendingUp, label: "Deals", path: "/deals" },
  { icon: FolderLock, label: "Deal Rooms", path: "/deal-rooms" },
  { icon: Shield, label: "Compliance", path: "/compliance" },
  { icon: History, label: "Audit Logs", path: "/audit-logs" },
  { icon: Gem, label: "Commodities", path: "/commodities" },
  { icon: Home, label: "Real Estate", path: "/real-estate" },
  { icon: Zap, label: "Transaction Matching", path: "/transaction-matching" },
  { icon: TrendingUp, label: "Trading Platform", path: "/trading" },
  { icon: Users, label: "Member Onboarding", path: "/member-onboarding" },
  { icon: DollarSign, label: "Fee Management", path: "/fee-management" },
  { icon: Coins, label: "Crypto Assets", path: "/crypto-assets", highlight: true },
  { icon: DollarSign, label: "Payouts", path: "/payouts" },
  { icon: Network, label: "Network", path: "/network" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 260;
const MIN_WIDTH = 200;
const MAX_WIDTH = 400;

// Demo user for public access
const demoUser = {
  name: "Avraham",
  email: "avraham@anavi.io",
  avatar: "/avraham.png"
};

// Animation variants
const menuItemVariants = {
  hidden: { opacity: 0, x: -10 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: {
      delay: i * 0.02,
      duration: 0.3,
      ease: [0.25, 0.1, 0.25, 1] as const
    }
  })
};

const logoVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.4,
      ease: [0.25, 0.1, 0.25, 1] as const
    }
  }
};

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": `${sidebarWidth}px`,
        } as CSSProperties
      }
    >
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
  );
}

type DashboardLayoutContentProps = {
  children: React.ReactNode;
  setSidebarWidth: (width: number) => void;
};

function DashboardLayoutContent({
  children,
  setSidebarWidth,
}: DashboardLayoutContentProps) {
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const activeMenuItem = menuItems.find(item => item.path === location);
  const isMobile = useIsMobile();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  useEffect(() => {
    if (isCollapsed) {
      setIsResizing(false);
    }
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;

      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) {
        setSidebarWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar
          collapsible="icon"
          className="border-r border-border/50 bg-sidebar"
          disableTransition={isResizing}
        >
          <SidebarHeader className="h-16 justify-center border-b border-border/50">
            <motion.div 
              className="flex items-center gap-3 px-3 transition-all w-full"
              initial="hidden"
              animate="visible"
              variants={logoVariants}
            >
              <motion.button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-sidebar-accent transition-all focus:outline-none shrink-0 relative overflow-hidden"
                aria-label="Toggle navigation"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  className="absolute inset-0 bg-accent/20"
                  initial={{ scale: 0, opacity: 0 }}
                  whileHover={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.2 }}
                />
                <PanelLeft className="h-4 w-4 text-sidebar-foreground/60 relative z-10" />
              </motion.button>
              <AnimatePresence mode="wait">
                {!isCollapsed ? (
                  <motion.div 
                    className="flex items-center gap-1"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    <span className="text-xl font-medium tracking-tight text-sidebar-foreground">@</span>
                    <span className="text-xl font-medium tracking-tight text-sidebar-foreground">navi</span>
                    <motion.span 
                      className="w-1.5 h-1.5 rounded-full bg-sky-500 mb-3"
                      animate={{ 
                        scale: [1, 1.3, 1],
                        opacity: [1, 0.7, 1]
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                  </motion.div>
                ) : (
                  <motion.span 
                    className="text-lg font-medium text-sidebar-foreground"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    @
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.div>
          </SidebarHeader>

          <SidebarContent className="gap-0 py-4 scrollbar-premium">
            <SidebarMenu className="px-2 space-y-0.5">
              {menuItems.map((item, i) => {
                const isActive = location === item.path;
                const isHovered = hoveredItem === item.path;
                return (
                  <motion.div
                    key={item.path}
                    custom={i}
                    initial="hidden"
                    animate="visible"
                    variants={menuItemVariants}
                  >
                    <SidebarMenuItem>
                      <SidebarMenuButton
                        isActive={isActive}
                        onClick={() => setLocation(item.path)}
                        onMouseEnter={() => setHoveredItem(item.path)}
                        onMouseLeave={() => setHoveredItem(null)}
                        tooltip={item.label}
                        className={`h-10 transition-all duration-200 font-medium relative overflow-hidden rounded ${
                          isActive 
                            ? "bg-sky-500/15 text-sky-400" 
                            : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                        } ${item.highlight ? "text-sky-400" : ""}`}
                      >
                        {/* Hover background effect */}
                        <motion.div
                          className="absolute inset-0 bg-accent/10"
                          initial={{ opacity: 0, x: "-100%" }}
                          animate={{ 
                            opacity: isHovered && !isActive ? 1 : 0,
                            x: isHovered && !isActive ? 0 : "-100%"
                          }}
                          transition={{ duration: 0.2 }}
                        />
                        
                        {/* Active indicator - sky blue */}
                        {isActive && (
                          <motion.div
                            className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-sky-500"
                            layoutId="activeIndicator"
                            transition={{ type: "spring", stiffness: 300, damping: 30 }}
                          />
                        )}
                        
                        <motion.div
                          animate={{ 
                            scale: isHovered ? 1.1 : 1,
                            rotate: isHovered ? 5 : 0
                          }}
                          transition={{ duration: 0.2 }}
                        >
                          <item.icon className="h-4 w-4 relative z-10" />
                        </motion.div>
                        <span className="text-sm relative z-10">{item.label}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </motion.div>
                );
              })}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="p-3 border-t border-border/50">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <motion.button 
                  className="flex items-center gap-3 px-2 py-2 hover:bg-sidebar-accent transition-all w-full text-left focus:outline-none relative overflow-hidden group"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                >
                  <motion.div
                    className="absolute inset-0 bg-accent/5"
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                    transition={{ duration: 0.2 }}
                  />
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Avatar className="h-8 w-8 shrink-0 ring-2 ring-transparent group-hover:ring-accent/30 transition-all">
                      <AvatarImage src={demoUser.avatar} alt={demoUser.name} />
                      <AvatarFallback className="text-xs font-medium bg-accent text-foreground">
                        {demoUser.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </motion.div>
                  <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden relative z-10">
                    <p className="text-sm font-medium truncate leading-none text-sidebar-foreground">
                      {demoUser.name}
                    </p>
                    <p className="text-xs text-sidebar-foreground/50 truncate mt-1">
                      {demoUser.email}
                    </p>
                  </div>
                </motion.button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  onClick={() => setLocation("/")}
                  className="cursor-pointer"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Exit Demo</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>
        
        {/* Resize handle with glow effect */}
        <motion.div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => {
            if (isCollapsed) return;
            setIsResizing(true);
          }}
          style={{ zIndex: 50 }}
          whileHover={{ 
            backgroundColor: "oklch(0.72 0.14 70 / 0.5)",
            boxShadow: "0 0 10px oklch(0.72 0.14 70 / 0.3)"
          }}
        />
      </div>

      <SidebarInset>
        {isMobile && (
          <motion.div 
            className="flex border-b border-border/50 h-14 items-center justify-between bg-background/80 backdrop-blur-sm px-4 sticky top-0 z-40"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex items-center gap-3">
              <SidebarTrigger className="h-8 w-8 bg-foreground text-background" />
              <motion.span 
                className="font-medium text-foreground"
                key={activeMenuItem?.label}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
              >
                {activeMenuItem?.label ?? "Menu"}
              </motion.span>
            </div>
          </motion.div>
        )}
        <motion.main 
          className="flex-1 bg-background"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.main>
      </SidebarInset>
    </>
  );
}

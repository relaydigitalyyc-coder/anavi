// Re-export AuthDialog as ManusDialog for backward compatibility
export { AuthDialog as ManusDialog } from "./AuthDialog";

import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  DollarSign, TrendingUp, Clock, CheckCircle2, 
  ArrowUpRight, Wallet, PieChart,
  Calendar, Download
} from "lucide-react";

export default function Payouts() {
  const { data: payouts, isLoading } = trpc.payout.list.useQuery();

  const totalEarnings = payouts?.reduce((sum, p) => sum + parseFloat(p.amount), 0) || 0;
  const pendingPayouts = payouts?.filter(p => p.status === 'pending') || [];
  const completedPayouts = payouts?.filter(p => p.status === 'completed') || [];

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "pending": return "bg-sky-100 text-sky-700";
      case "processing": return "bg-blue-100 text-blue-700";
      case "completed": return "bg-sky-100 text-sky-700";
      case "failed": return "bg-red-100 text-red-700";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getPayoutTypeLabel = (type: string) => {
    switch (type) {
      case "originator_fee": return "Originator Fee";
      case "introducer_fee": return "Introducer Fee";
      case "advisor_fee": return "Advisor Fee";
      case "platform_fee": return "Platform Fee";
      case "bonus": return "Bonus";
      default: return type;
    }
  };

  return (
    <div className="p-8 space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-50 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-sky-600" />
            </div>
            Payouts & Earnings
          </h1>
          <p className="text-muted-foreground mt-2">
            Track your earnings from deal origination and introductions
          </p>
        </div>
        <Button variant="outline" className="hover:border-primary hover:text-primary">
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Earnings Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="premium-card border-sky-200 bg-gradient-to-br from-emerald-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Earnings</p>
                <p className="text-3xl font-bold text-sky-600 mt-1 number-display">
                  ${totalEarnings.toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-sky-100 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-sky-600" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-sm">
              <ArrowUpRight className="w-4 h-4 text-sky-600" />
              <span className="text-sky-600 font-medium">+12.5%</span>
              <span className="text-muted-foreground">vs last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="premium-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Payouts</p>
                <p className="text-3xl font-bold mt-1 number-display">
                  ${pendingPayouts.reduce((sum, p) => sum + parseFloat(p.amount), 0).toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-sky-50 flex items-center justify-center">
                <Clock className="w-6 h-6 text-sky-600" />
              </div>
            </div>
            <div className="text-sm text-muted-foreground mt-3">
              {pendingPayouts.length} payouts awaiting
            </div>
          </CardContent>
        </Card>

        <Card className="premium-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">This Month</p>
                <p className="text-3xl font-bold mt-1 number-display gradient-text-gold">$0</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Calendar className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="text-sm text-muted-foreground mt-3">
              From 0 deals
            </div>
          </CardContent>
        </Card>

        <Card className="premium-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Completed Deals</p>
                <p className="text-3xl font-bold mt-1 number-display">{completedPayouts.length}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-muted-foreground" />
              </div>
            </div>
            <div className="text-sm text-muted-foreground mt-3">
              Lifetime total
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attribution Breakdown */}
      <Card className="premium-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <PieChart className="w-5 h-5 text-primary" />
            Earnings by Attribution Type
          </CardTitle>
          <CardDescription>
            Breakdown of your earnings by role in deals
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-gradient-to-br from-primary/5 to-amber-500/5 border border-primary/10">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium">Originator Fees</span>
                <span className="text-xl font-bold gradient-text-gold">60%</span>
              </div>
              <Progress value={60} className="h-2 mb-3" />
              <p className="text-sm text-muted-foreground">
                Earnings from deals you originated
              </p>
            </div>

            <div className="p-5 rounded-xl bg-gradient-to-br from-purple-50 to-white border border-purple-100">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium">Introducer Fees</span>
                <span className="text-xl font-bold text-purple-600">30%</span>
              </div>
              <Progress value={30} className="h-2 mb-3" />
              <p className="text-sm text-muted-foreground">
                Earnings from introductions made
              </p>
            </div>

            <div className="p-5 rounded-xl bg-gradient-to-br from-emerald-50 to-white border border-emerald-100">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium">Advisor Fees</span>
                <span className="text-xl font-bold text-sky-600">10%</span>
              </div>
              <Progress value={10} className="h-2 mb-3" />
              <p className="text-sm text-muted-foreground">
                Earnings from advisory roles
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payout History */}
      <Card className="premium-card">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Payout History</CardTitle>
          <CardDescription>
            All your earnings and payout transactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-20 animate-shimmer rounded-xl" />
              ))}
            </div>
          ) : !payouts || payouts.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
                <Wallet className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No Payouts Yet</h3>
              <p className="text-muted-foreground max-w-sm mx-auto">
                Complete deals to start earning. Your first payout will appear here.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {payouts.map((payout, index) => (
                <div
                  key={payout.id}
                  className="flex items-center justify-between p-5 rounded-xl border border-border hover:border-primary/30 hover:shadow-sm transition-all"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      payout.status === 'completed' ? 'bg-sky-50' : 'bg-sky-50'
                    }`}>
                      {payout.status === 'completed' ? (
                        <CheckCircle2 className="w-6 h-6 text-sky-600" />
                      ) : (
                        <Clock className="w-6 h-6 text-sky-600" />
                      )}
                    </div>
                    <div>
                      <div className="font-semibold">{getPayoutTypeLabel(payout.payoutType)}</div>
                      <div className="text-sm text-muted-foreground">
                        Deal #{payout.dealId} • {new Date(payout.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-sky-600 number-display">
                      +${parseFloat(payout.amount).toLocaleString()}
                    </div>
                    <Badge className={`${getStatusStyle(payout.status || 'pending')} border-0 mt-1`}>
                      {payout.status || 'pending'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Economics Explanation */}
      <Card className="premium-card border-primary/20 bg-gradient-to-r from-primary/5 to-amber-500/5">
        <CardContent className="p-8">
          <h3 className="font-semibold text-lg mb-6">@navi Economics Model</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary" />
                Originator Share (40-60%)
              </h4>
              <p className="text-muted-foreground leading-relaxed">
                As the deal originator, you receive the largest share of intermediary fees. 
                Your relationships and introductions are the foundation of every deal.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-sky-500" />
                Lifetime Attribution
              </h4>
              <p className="text-muted-foreground leading-relaxed">
                Follow-on deals from your introductions continue to earn you fees. 
                Your network compounds in value over time.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-sky-500" />
                Milestone-Based Payouts
              </h4>
              <p className="text-muted-foreground leading-relaxed">
                Payouts are triggered at key deal milestones (Term Sheet, Closing) 
                ensuring alignment with deal progress.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-purple-500" />
                Transparent Tracking
              </h4>
              <p className="text-muted-foreground leading-relaxed">
                Every attribution is cryptographically timestamped and tracked. 
                No disputes, no ambiguity.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

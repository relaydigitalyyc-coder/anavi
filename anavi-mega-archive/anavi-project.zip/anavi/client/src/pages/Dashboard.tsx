import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { 
  Users, 
  Target, 
  Handshake, 
  TrendingUp,
  ArrowUpRight,
  Plus,
  Shield,
  Building2,
  Bell,
  ChevronRight,
  Sparkles,
  Zap
} from "lucide-react";
import { Link } from "wouter";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { useRef, useState } from "react";
import { 
  AnimatedCounter, 
  RevealOnScroll, 
  HoverCard, 
  AnimatedBorder,
  TextReveal,
  Magnetic,
  AnimatedDivider,
  Glow
} from "@/components/AwwwardsAnimations";
import {
  LiquidGradient,
  Card3D,
  SmoothReveal,
  GradientText,
  Spotlight,
  SmoothCounter,
  StaggeredList,
  MorphingBlob,
} from "@/components/PremiumAnimations";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats } = trpc.user.getStats.useQuery();
  const { data: notifications } = trpc.notification.list.useQuery({ limit: 5 });
  const headerRef = useRef(null);
  const isHeaderInView = useInView(headerRef, { once: true });
  const [hoveredMetric, setHoveredMetric] = useState<number | null>(null);

  const metrics = [
    {
      label: "Relationships",
      value: stats?.relationshipCount || 0,
      change: "+12%",
      icon: Users,
      sublabel: "Custodied",
      href: "/relationships",
      color: "from-sky-500/15 to-transparent"
    },
    {
      label: "Active Intents",
      value: stats?.intentCount || 0,
      change: "+8%",
      icon: Target,
      sublabel: "Matching",
      href: "/intents",
      color: "from-teal-500/15 to-transparent"
    },
    {
      label: "Pending Matches",
      value: stats?.matchCount || 0,
      change: "+24%",
      icon: Handshake,
      sublabel: "Awaiting",
      href: "/matches",
      color: "from-emerald-500/15 to-transparent"
    },
    {
      label: "Active Deals",
      value: stats?.dealCount || 0,
      change: "+15%",
      icon: TrendingUp,
      sublabel: `$${(stats?.totalDealValue || 0).toLocaleString()}`,
      href: "/deals",
      color: "from-sky-400/15 to-transparent"
    }
  ];

  const quickActions = [
    { label: "New Relationship", href: "/relationships", icon: Users },
    { label: "Post Intent", href: "/intents", icon: Target },
    { label: "Family Offices", href: "/family-offices", icon: Building2 },
    { label: "Verify Identity", href: "/settings", icon: Shield }
  ];

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-background relative overflow-hidden">
        {/* Premium Background Effects */}
        <LiquidGradient className="opacity-20" />
        <MorphingBlob className="w-[400px] h-[400px] -top-[100px] -right-[100px] opacity-30" color="oklch(0.72 0.14 70 / 0.1)" />
        
        {/* Header with premium reveal animation */}
        <header ref={headerRef} className="border-b border-border/50 relative z-10 backdrop-blur-sm bg-background/50">
          <div className="px-4 md:px-8 py-6 md:py-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <motion.div
              initial={{ opacity: 0, x: -40, filter: "blur(10px)" }}
              animate={isHeaderInView ? { opacity: 1, x: 0, filter: "blur(0px)" } : {}}
              transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1] }}
            >
              <motion.div 
                className="flex items-center gap-2 mb-3"
                initial={{ opacity: 0, y: 10 }}
                animate={isHeaderInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.2 }}
              >
                <motion.span
                  animate={{ rotate: 360 }}
                  transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                >
                  <Sparkles className="w-4 h-4 text-accent" />
                </motion.span>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Dashboard
                </p>
              </motion.div>
              <h1 className="text-3xl md:text-5xl font-serif leading-tight">
                <span className="block overflow-hidden">
                  <motion.span
                    className="block"
                    initial={{ y: "100%" }}
                    animate={isHeaderInView ? { y: 0 } : {}}
                    transition={{ duration: 0.6, delay: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
                  >
                    Welcome back,
                  </motion.span>
                </span>
                <span className="block overflow-hidden">
                  <motion.span
                    className="block"
                    initial={{ y: "100%" }}
                    animate={isHeaderInView ? { y: 0 } : {}}
                    transition={{ duration: 0.6, delay: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
                  >
                    <GradientText>{user?.name || 'User'}</GradientText>
                  </motion.span>
                </span>
              </h1>
            </motion.div>
            <motion.div 
              className="flex items-center gap-4"
              initial={{ opacity: 0, x: 40, filter: "blur(10px)" }}
              animate={isHeaderInView ? { opacity: 1, x: 0, filter: "blur(0px)" } : {}}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <motion.span 
                className="px-5 py-2.5 border border-border/50 text-xs uppercase tracking-wider bg-background/50 backdrop-blur-sm"
                whileHover={{ borderColor: "oklch(0.72 0.14 70 / 0.5)", scale: 1.02 }}
                transition={{ duration: 0.2 }}
              >
                {stats?.verificationLevel || 'NONE'}
              </motion.span>
              <Link href="/intents">
                <Magnetic strength={0.15}>
                  <motion.button 
                    className="relative bg-accent text-foreground px-7 py-3 text-sm font-medium overflow-hidden group"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <motion.span
                      className="absolute inset-0 bg-white/20"
                      initial={{ x: "-100%", skewX: "-15deg" }}
                      whileHover={{ x: "200%" }}
                      transition={{ duration: 0.6 }}
                    />
                    <span className="relative flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      New Intent
                    </span>
                  </motion.button>
                </Magnetic>
              </Link>
            </motion.div>
          </div>
        </header>

        <div className="p-4 md:p-8 relative z-10">
          {/* Metrics Grid with premium hover effects */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5 mb-8 md:mb-10">
            {metrics.map((metric, i) => (
              <Link key={i} href={metric.href}>
                <motion.div
                  initial={{ opacity: 0, y: 40, filter: "blur(10px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  transition={{ 
                    duration: 0.6, 
                    delay: 0.1 + i * 0.1,
                    ease: [0.25, 0.1, 0.25, 1]
                  }}
                  onMouseEnter={() => setHoveredMetric(i)}
                  onMouseLeave={() => setHoveredMetric(null)}
                >
                  <Card3D intensity={6} glare={true}>
                    <motion.div 
                      className="relative bg-card/80 backdrop-blur-sm border border-border/50 p-6 md:p-8 cursor-pointer h-full overflow-hidden"
                      whileHover={{ borderColor: "oklch(0.72 0.14 70 / 0.5)" }}
                      transition={{ duration: 0.3 }}
                    >
                      {/* Gradient background on hover */}
                      <motion.div
                        className={`absolute inset-0 bg-gradient-to-br ${metric.color} opacity-0`}
                        animate={{ opacity: hoveredMetric === i ? 1 : 0 }}
                        transition={{ duration: 0.3 }}
                      />
                      
                      <div className="relative z-10">
                        <div className="flex items-start justify-between mb-6 md:mb-8">
                          <motion.div 
                            className="w-12 h-12 bg-muted/50 flex items-center justify-center"
                            whileHover={{ rotate: 5, scale: 1.05 }}
                            animate={{ 
                              backgroundColor: hoveredMetric === i ? "oklch(0.72 0.14 70 / 0.2)" : "oklch(0.5 0 0 / 0.1)"
                            }}
                            transition={{ duration: 0.3 }}
                          >
                            <metric.icon className="w-5 h-5 text-foreground" />
                          </motion.div>
                          <motion.span 
                            className="text-xs font-medium text-sky-500 flex items-center gap-1 px-2 py-1 bg-sky-500/10"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.5 + i * 0.1 }}
                          >
                            <ArrowUpRight className="w-3 h-3" />
                            {metric.change}
                          </motion.span>
                        </div>
                        <div className="text-3xl md:text-5xl font-light mb-2">
                          <SmoothCounter value={metric.value} duration={2} />
                        </div>
                        <div className="text-xs uppercase tracking-[0.15em] text-muted-foreground">{metric.label}</div>
                        <motion.div 
                          className="text-xs text-muted-foreground/60 mt-2"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 0.8 + i * 0.1 }}
                        >
                          {metric.sublabel}
                        </motion.div>
                      </div>
                    </motion.div>
                  </Card3D>
                </motion.div>
              </Link>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 md:gap-6">
            {/* Trust Score with premium animations */}
            <SmoothReveal delay={0.2}>
              <Spotlight className="h-full">
                <motion.div 
                  className="border border-border/50 p-6 md:p-8 bg-card/80 backdrop-blur-sm h-full"
                  whileHover={{ borderColor: "oklch(0.72 0.14 70 / 0.3)" }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-2">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                      >
                        <Zap className="w-4 h-4 text-accent" />
                      </motion.div>
                      <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Trust Score</p>
                    </div>
                    <Link href="/settings">
                      <motion.button 
                        className="text-xs uppercase tracking-wider text-accent hover:underline flex items-center gap-1 group"
                        whileHover={{ x: 3 }}
                      >
                        Improve
                        <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                      </motion.button>
                    </Link>
                  </div>
                  
                  <div className="flex items-end gap-6 mb-8">
                    <motion.p 
                      className="text-5xl md:text-6xl font-light"
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5, type: "spring", stiffness: 100 }}
                    >
                      <SmoothCounter 
                        value={Number(stats?.trustScore || 0) / 10} 
                        duration={2.5} 
                      />
                    </motion.p>
                    <div className="pb-2">
                      <p className="text-xs uppercase tracking-wider text-muted-foreground">Level</p>
                      <p className="text-sm font-medium">{stats?.verificationLevel || 'none'}</p>
                    </div>
                  </div>
                  
                  {/* Animated Score Bar */}
                  <div className="h-1 bg-border/30 mb-8 overflow-hidden relative">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-accent via-accent to-accent/50"
                      initial={{ width: 0 }}
                      animate={{ width: `${stats?.trustScore || 0}%` }}
                      transition={{ duration: 1.5, delay: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
                    />
                    <motion.div
                      className="absolute top-0 left-0 h-full w-20 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                      animate={{ x: ["-100%", "500%"] }}
                      transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 pt-6 border-t border-border/30">
                    {[
                      { value: stats?.dealCount || 0, label: "Deals" },
                      { value: Number(stats?.totalEarnings || 0) / 1000, label: "Earnings", prefix: "$", suffix: "K" },
                      { value: stats?.relationshipCount || 0, label: "Network" }
                    ].map((stat, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 1 + i * 0.1 }}
                        className="text-center"
                      >
                        <p className="text-xl md:text-2xl font-light">
                          <SmoothCounter 
                            value={stat.value} 
                            prefix={stat.prefix || ""} 
                            suffix={stat.suffix || ""}
                          />
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </Spotlight>
            </SmoothReveal>

            {/* Recent Activity with staggered items */}
            <SmoothReveal delay={0.3}>
              <motion.div 
                className="border border-border/50 p-6 md:p-8 bg-card/80 backdrop-blur-sm h-full"
                whileHover={{ borderColor: "oklch(0.72 0.14 70 / 0.3)" }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-accent" />
                    <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Activity</p>
                  </div>
                  <p className="text-sm text-muted-foreground">Recent</p>
                </div>
                
                <AnimatePresence mode="wait">
                  {notifications && notifications.length > 0 ? (
                    <motion.div className="space-y-3">
                      {notifications.slice(0, 4).map((notification: any, i: number) => (
                        <motion.div 
                          key={notification.id}
                          initial={{ opacity: 0, x: -20, filter: "blur(5px)" }}
                          animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                          transition={{ delay: 0.5 + i * 0.1 }}
                          className="flex items-start gap-4 p-4 border border-border/30 hover:border-accent/50 hover:bg-accent/5 transition-all cursor-pointer group"
                          whileHover={{ x: 4 }}
                        >
                          <motion.div 
                            className="w-10 h-10 bg-muted/50 flex items-center justify-center flex-shrink-0 group-hover:bg-accent/20 transition-colors"
                            whileHover={{ rotate: 10, scale: 1.05 }}
                          >
                            <Bell className="w-4 h-4" />
                          </motion.div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate group-hover:text-accent transition-colors">{notification.title}</p>
                            <p className="text-xs text-muted-foreground truncate mt-1">{notification.message}</p>
                          </div>
                          <ChevronRight className="w-4 h-4 text-muted-foreground/30 group-hover:text-accent transition-colors" />
                        </motion.div>
                      ))}
                    </motion.div>
                  ) : (
                    <motion.div 
                      className="flex flex-col items-center justify-center py-12 text-center"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5 }}
                    >
                      <motion.div 
                        className="w-16 h-16 bg-muted/30 flex items-center justify-center mb-4"
                        animate={{ y: [0, -8, 0] }}
                        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                      >
                        <Bell className="w-6 h-6 text-muted-foreground" />
                      </motion.div>
                      <p className="text-sm text-muted-foreground">No new notifications</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </SmoothReveal>

            {/* Quick Actions with premium hover effects */}
            <SmoothReveal delay={0.4}>
              <motion.div 
                className="bg-foreground text-background p-6 md:p-8 h-full relative overflow-hidden"
                whileHover={{ scale: 1.01 }}
                transition={{ duration: 0.3 }}
              >
                {/* Animated background pattern */}
                <motion.div
                  className="absolute inset-0 opacity-5"
                  style={{
                    backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
                    backgroundSize: "24px 24px"
                  }}
                  animate={{ backgroundPosition: ["0px 0px", "24px 24px"] }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                />
                
                <div className="relative z-10">
                  <p className="text-xs uppercase tracking-[0.2em] text-background/40 mb-2">Quick Actions</p>
                  <p className="text-3xl font-serif text-background mb-8">Get Started</p>
                  
                  <div className="space-y-3">
                    {quickActions.map((action, i) => (
                      <Link key={i} href={action.href}>
                        <motion.div 
                          className="flex items-center gap-4 p-4 border border-background/10 hover:border-accent hover:bg-background/5 transition-all group cursor-pointer"
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.6 + i * 0.1 }}
                          whileHover={{ x: 6 }}
                        >
                          <motion.div 
                            className="w-10 h-10 bg-background/10 flex items-center justify-center group-hover:bg-accent transition-colors"
                            whileHover={{ rotate: -10, scale: 1.05 }}
                          >
                            <action.icon className="w-4 h-4 text-background" />
                          </motion.div>
                          <span className="text-sm text-background font-medium">{action.label}</span>
                          <motion.div
                            className="ml-auto"
                            initial={{ x: 0, opacity: 0.3 }}
                            whileHover={{ x: 3, opacity: 1 }}
                          >
                            <ChevronRight className="w-4 h-4 text-background/40 group-hover:text-accent transition-colors" />
                          </motion.div>
                        </motion.div>
                      </Link>
                    ))}
                  </div>
                </div>
              </motion.div>
            </SmoothReveal>
          </div>

          {/* Animated Divider */}
          <div className="my-10 md:my-12">
            <AnimatedDivider direction="center" />
          </div>

          {/* Network Stats with premium counter animations */}
          <motion.div 
            className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            {[
              { label: "Network Growth", value: stats?.relationshipCount || 0, sublabel: "Total Connections" },
              { label: "Deal Pipeline", value: stats?.dealCount || 0, sublabel: "Active Deals" },
              { label: "Match Rate", value: stats?.matchCount || 0, sublabel: "Pending Matches" },
              { label: "Total Earnings", value: Number(stats?.totalEarnings || 0) / 1000, sublabel: "Lifetime", prefix: "$", suffix: "K", isGold: true }
            ].map((stat, i) => (
              <motion.div
                key={i}
                className="bg-card/80 backdrop-blur-sm border border-border/50 p-6 md:p-8"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 + i * 0.1 }}
                whileHover={{ 
                  borderColor: "oklch(0.72 0.14 70 / 0.3)",
                  backgroundColor: "oklch(0.72 0.14 70 / 0.03)"
                }}
              >
                <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground mb-3">{stat.label}</p>
                <p className={`text-2xl md:text-4xl font-light ${stat.isGold ? 'text-accent' : ''}`}>
                  <SmoothCounter 
                    value={stat.value} 
                    prefix={stat.prefix || ""} 
                    suffix={stat.suffix || ""}
                    duration={2.5}
                  />
                </p>
                <p className="text-xs text-muted-foreground mt-2">{stat.sublabel}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </DashboardLayout>
  );
}

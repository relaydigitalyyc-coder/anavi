import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Users, Plus, Search, Lock, Unlock, Shield, 
  Clock, DollarSign, MessageSquare, 
  Copy, CheckCircle2, TrendingUp, ChevronRight, Filter
} from "lucide-react";
import { toast } from "sonner";

export default function Relationships() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newRelationship, setNewRelationship] = useState({
    contactId: "",
    relationshipType: "direct" as const,
    notes: "",
  });

  const { data: relationships, isLoading, refetch } = trpc.relationship.list.useQuery();
  const createMutation = trpc.relationship.create.useMutation({
    onSuccess: () => {
      toast.success("Relationship created with cryptographic timestamp!");
      setIsAddDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const filteredRelationships = relationships?.filter(rel => 
    rel.notes?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    rel.relationshipType?.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const copyTimestampHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    toast.success("Timestamp hash copied to clipboard");
  };

  const totalEarnings = relationships?.reduce((sum, r) => sum + parseFloat(r.totalEarnings || "0"), 0) || 0;

  const stats = [
    { label: "Total Relationships", value: relationships?.length || 0, icon: Users, color: "accent" },
    { label: "Protected (Blind)", value: relationships?.filter(r => r.isBlind).length || 0, icon: Lock, color: "dark" },
    { label: "Strong Connections", value: relationships?.filter(r => r.strength === 'strong' || r.strength === 'very_strong').length || 0, icon: TrendingUp, color: "accent" },
    { label: "Total Earnings", value: `$${totalEarnings.toFixed(0)}`, icon: DollarSign, color: "dark", isEarnings: true },
  ];

  return (
    <div className="min-h-screen bg-background bg-geometric">
      {/* Header */}
      <div className="px-8 pt-10 pb-8">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
          <div className="animate-fade-in">
            <div className="flex items-center gap-3 mb-4">
              <div className="geo-dot" />
              <span className="text-[0.6875rem] font-semibold uppercase tracking-widest text-muted-foreground">Relationship Custody</span>
            </div>
            <h1 className="text-display-lg text-foreground mb-3">
              Your <span className="gradient-text">Network</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-md">
              Cryptographically protected relationships with attribution tracking.
            </p>
          </div>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <button className="btn-accent flex items-center gap-2 animate-fade-in stagger-2">
                <Plus className="w-4 h-4" />
                Add Relationship
              </button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-display-sm">Add Relationship</DialogTitle>
                <DialogDescription>
                  Register with cryptographic timestamp proof
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Contact ID</Label>
                  <Input
                    placeholder="Enter contact user ID"
                    value={newRelationship.contactId}
                    onChange={(e) => setNewRelationship({ ...newRelationship, contactId: e.target.value })}
                    className="h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Relationship Type</Label>
                  <Select
                    value={newRelationship.relationshipType}
                    onValueChange={(value: any) => setNewRelationship({ ...newRelationship, relationshipType: value })}
                  >
                    <SelectTrigger className="h-11">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="direct">Direct Contact</SelectItem>
                      <SelectItem value="introduction">Introduction</SelectItem>
                      <SelectItem value="referral">Referral</SelectItem>
                      <SelectItem value="network">Network Connection</SelectItem>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="personal">Personal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    placeholder="Add notes about this relationship..."
                    value={newRelationship.notes}
                    onChange={(e) => setNewRelationship({ ...newRelationship, notes: e.target.value })}
                    rows={3}
                  />
                </div>
                <button
                  className="btn-primary w-full"
                  onClick={() => {
                    if (!newRelationship.contactId) {
                      toast.error("Please enter a contact ID");
                      return;
                    }
                    createMutation.mutate({
                      contactId: parseInt(newRelationship.contactId),
                      relationshipType: newRelationship.relationshipType,
                      notes: newRelationship.notes,
                    });
                  }}
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? "Creating..." : "Create Relationship"}
                </button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search */}
      <div className="px-8 pb-6">
        <div className="flex flex-col sm:flex-row gap-4 animate-fade-in stagger-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search relationships..."
              className="pl-11 h-12 rounded-xl"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <button className="btn-ghost flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="px-8 pb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 animate-fade-in stagger-4">
          {stats.map((stat, index) => (
            <div key={index} className="metric-card p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                  stat.color === 'accent' ? 'icon-container-accent' : 'icon-container-dark'
                }`}>
                  <stat.icon className={`w-5 h-5 ${
                    stat.color === 'accent' ? 'text-accent' : 'text-primary-foreground'
                  }`} />
                </div>
              </div>
              <div className={`text-number-lg mb-1 ${stat.isEarnings ? 'gradient-text' : 'text-foreground'}`}>
                {stat.value}
              </div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Relationships List */}
      <div className="px-8 pb-12">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card-editorial p-6">
                <div className="h-32 animate-shimmer rounded-xl" />
              </div>
            ))}
          </div>
        ) : filteredRelationships.length === 0 ? (
          <div className="card-editorial p-16 text-center">
            <div className="w-20 h-20 rounded-2xl icon-container mx-auto mb-6 flex items-center justify-center">
              <Users className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-display-sm text-foreground mb-2">No Relationships Yet</h3>
            <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
              Start building your network with cryptographic custody protection
            </p>
            <button onClick={() => setIsAddDialogOpen(true)} className="btn-accent">
              <Plus className="w-4 h-4 mr-2" />
              Add First Relationship
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredRelationships.map((relationship, index) => (
              <div 
                key={relationship.id} 
                className={`card-editorial p-6 hover-lift cursor-pointer group animate-fade-in stagger-${Math.min(index + 1, 8)}`}
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-14 h-14 rounded-xl geo-circle flex items-center justify-center text-lg font-bold text-primary">
                        {relationship.contactId}
                      </div>
                      <div>
                        <div className="flex items-center gap-3">
                          <span className="font-semibold text-lg text-foreground group-hover:text-accent transition-colors">
                            Contact #{relationship.contactId}
                          </span>
                          {relationship.isBlind ? (
                            <span className="badge-dark text-[10px]">
                              <Lock className="w-3 h-3 mr-1" />
                              Protected
                            </span>
                          ) : (
                            <span className="badge-outline text-[10px]">
                              <Unlock className="w-3 h-3 mr-1" />
                              Visible
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          {(relationship.relationshipType || 'direct').charAt(0).toUpperCase() + (relationship.relationshipType || 'direct').slice(1)} Connection
                        </div>
                      </div>
                    </div>
                    
                    {relationship.notes && (
                      <p className="text-muted-foreground leading-relaxed mb-4">{relationship.notes}</p>
                    )}

                    <div className="flex flex-wrap gap-6 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        <span>Est. {new Date(relationship.establishedAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Shield className="w-4 h-4" />
                        <span className="capitalize">Strength: {relationship.strength}</span>
                      </div>
                      <div className="flex items-center gap-2 gradient-text font-medium">
                        <DollarSign className="w-4 h-4" />
                        <span>${relationship.totalEarnings || "0"} earned</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MessageSquare className="w-4 h-4" />
                        <span>{relationship.dealCount || 0} deals</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <button
                      className="btn-ghost text-sm flex items-center gap-2"
                      onClick={() => copyTimestampHash(relationship.timestampHash)}
                    >
                      <Copy className="w-4 h-4" />
                      Copy Proof
                    </button>
                    <button className="btn-ghost text-sm flex items-center gap-2">
                      View Details
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Timestamp Proof */}
                <div className="mt-5 p-4 rounded-xl bg-muted/30 border border-border">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-500" />
                    <span className="font-semibold">Cryptographic Timestamp Proof</span>
                  </div>
                  <code className="text-xs font-mono text-muted-foreground break-all">{relationship.timestampHash}</code>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

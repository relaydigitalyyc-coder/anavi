import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Building2, Users, DollarSign, Shield, FileText, 
  AlertTriangle, CheckCircle2, ArrowRight, Briefcase,
  TrendingUp, Calendar, MapPin, User, Lock, Eye,
  Download, ExternalLink, Heart
} from "lucide-react";
import { toast } from "sonner";

// Curated deals - 5-10 real, live opportunities only
const curatedDeals = [
  {
    id: 1,
    title: "Meridian Industrial Portfolio",
    subtitle: "10-Building Last-Mile Logistics Portfolio",
    sponsor: {
      name: "Marcus Chen",
      title: "Managing Partner, Meridian Capital",
      image: "/avraham-profile.png",
      track: "15 years CRE, $2.4B deployed",
      verified: true,
    },
    thesis: `The last-mile logistics sector continues to experience unprecedented demand driven by e-commerce acceleration. This portfolio of 10 Class-A industrial buildings across the Northeast corridor offers immediate cash flow with significant value-add potential through lease-up of recently vacated space.

Key Investment Thesis:
• 94% occupancy with Amazon, FedEx, and UPS as anchor tenants
• Below-market rents with 15-20% mark-to-market opportunity
• Strategic locations within 30 miles of major population centers
• 7-year weighted average lease term provides stability`,
    capitalStructure: {
      targetRaise: 45000000,
      minimumInvestment: 250000,
      maximumInvestment: 5000000,
      totalProjectCost: 425000000,
      equityRequired: 127500000,
      seniorDebt: 297500000,
      ltv: 70,
    },
    fees: {
      managementFee: 1.5,
      carriedInterest: 20,
      preferredReturn: 8,
    },
    projectedReturns: {
      targetIRR: 18,
      targetMultiple: 1.9,
      holdPeriod: "5-7 years",
      cashOnCash: 7.5,
    },
    risks: [
      "E-commerce growth deceleration could impact tenant demand",
      "Interest rate increases may compress exit cap rates",
      "Single-tenant concentration risk (Amazon = 35% of NOI)",
      "Environmental remediation required on 2 parcels",
    ],
    naviInvolvement: {
      type: "Co-Invest",
      amount: 2500000,
      role: "NAVI principals investing alongside LPs with identical terms",
    },
    timeline: {
      closeDate: "March 15, 2026",
      acquisitionDate: "April 1, 2026",
      firstDistribution: "Q3 2026",
    },
    documents: [
      { name: "Private Placement Memorandum", type: "pdf" },
      { name: "Operating Agreement", type: "pdf" },
      { name: "Property Appraisals", type: "pdf" },
      { name: "Environmental Reports", type: "pdf" },
    ],
    status: "open",
    softCommitments: 28500000,
    interestedParties: 12,
    assetClass: "Real Estate",
    geography: "Northeast US",
  },
  {
    id: 2,
    title: "Quantum AI Series B",
    subtitle: "Enterprise AI Infrastructure Platform",
    sponsor: {
      name: "Sarah Blackwell",
      title: "General Partner, Nexus Ventures",
      image: "/avraham-profile.png",
      track: "Ex-Sequoia, 3 unicorn exits",
      verified: true,
    },
    thesis: `Quantum AI has built the leading enterprise infrastructure platform for deploying and managing AI models at scale. With $45M ARR growing 180% YoY and customers including 4 Fortune 100 companies, this Series B represents an opportunity to invest alongside top-tier VCs at a compelling valuation.

Key Investment Thesis:
• Category-defining product with 95% gross retention
• Land-and-expand model driving 145% net revenue retention
• Clear path to profitability within 18 months
• Strategic acquirer interest from major cloud providers`,
    capitalStructure: {
      targetRaise: 15000000,
      minimumInvestment: 100000,
      maximumInvestment: 2000000,
      totalProjectCost: 75000000,
      equityRequired: 75000000,
      seniorDebt: 0,
      ltv: 0,
    },
    fees: {
      managementFee: 2.0,
      carriedInterest: 20,
      preferredReturn: 0,
    },
    projectedReturns: {
      targetIRR: 35,
      targetMultiple: 4.0,
      holdPeriod: "4-6 years",
      cashOnCash: 0,
    },
    risks: [
      "Competitive pressure from hyperscalers (AWS, GCP, Azure)",
      "Key person risk - CEO/CTO concentration",
      "Regulatory uncertainty around AI governance",
      "Illiquidity - no secondary market",
    ],
    naviInvolvement: {
      type: "Advisory",
      amount: 500000,
      role: "NAVI advisory board seat, strategic introductions",
    },
    timeline: {
      closeDate: "February 28, 2026",
      acquisitionDate: "March 1, 2026",
      firstDistribution: "Exit event",
    },
    documents: [
      { name: "Investment Memo", type: "pdf" },
      { name: "Financial Model", type: "xlsx" },
      { name: "Technical Due Diligence", type: "pdf" },
      { name: "Cap Table", type: "pdf" },
    ],
    status: "open",
    softCommitments: 11200000,
    interestedParties: 8,
    assetClass: "Venture Capital",
    geography: "San Francisco, CA",
  },
  {
    id: 3,
    title: "Gold Dory Acquisition",
    subtitle: "West African Gold Mining Operation",
    sponsor: {
      name: "David Okonkwo",
      title: "CEO, Sahel Resources",
      image: "/avraham-profile.png",
      track: "20 years mining, 3 successful exits",
      verified: true,
    },
    thesis: `Sahel Resources has secured exclusive rights to acquire a producing gold mine in Ghana with proven reserves of 2.1M ounces. The operation currently produces 45,000 oz/year with clear expansion potential to 80,000 oz/year through capital investment in processing capacity.

Key Investment Thesis:
• All-in sustaining cost of $1,050/oz vs. spot price of $2,400/oz
• Proven reserves with 15+ year mine life
• Experienced local management team in place
• Expansion capex fully funded from operating cash flow`,
    capitalStructure: {
      targetRaise: 35000000,
      minimumInvestment: 500000,
      maximumInvestment: 5000000,
      totalProjectCost: 85000000,
      equityRequired: 50000000,
      seniorDebt: 35000000,
      ltv: 41,
    },
    fees: {
      managementFee: 2.0,
      carriedInterest: 25,
      preferredReturn: 10,
    },
    projectedReturns: {
      targetIRR: 28,
      targetMultiple: 2.5,
      holdPeriod: "5-7 years",
      cashOnCash: 12,
    },
    risks: [
      "Gold price volatility - $200/oz swing impacts returns significantly",
      "Political/regulatory risk in West Africa",
      "Operational execution risk on expansion",
      "Currency risk (GHS/USD)",
    ],
    naviInvolvement: {
      type: "Co-Invest",
      amount: 3000000,
      role: "NAVI principals co-investing, board observer seat",
    },
    timeline: {
      closeDate: "April 30, 2026",
      acquisitionDate: "May 15, 2026",
      firstDistribution: "Q4 2026",
    },
    documents: [
      { name: "Technical Report (NI 43-101)", type: "pdf" },
      { name: "Financial Model", type: "xlsx" },
      { name: "Legal Due Diligence", type: "pdf" },
      { name: "Environmental Impact Assessment", type: "pdf" },
    ],
    status: "open",
    softCommitments: 18700000,
    interestedParties: 6,
    assetClass: "Commodities",
    geography: "Ghana, West Africa",
  },
  {
    id: 4,
    title: "Bonny Light Crude Offtake",
    subtitle: "Nigerian Export Grade Crude Oil",
    sponsor: {
      name: "Emeka Adeyemi",
      title: "Director, Atlantic Energy Trading",
      image: "/avraham-profile.png",
      track: "Ex-Vitol, $8B traded volume",
      verified: true,
    },
    thesis: `Atlantic Energy has secured a 12-month offtake agreement for 2M barrels/month of Bonny Light crude from NNPC. This high-quality, low-sulfur crude commands a premium in European refineries. The trade is fully backed by letters of credit from tier-1 banks.

Key Investment Thesis:
• Bonny Light trades at $3-5/bbl premium to Brent
• LC-backed transactions eliminate counterparty risk
• 45-day cargo cycle provides rapid capital recycling
• Established relationships with European refiners`,
    capitalStructure: {
      targetRaise: 25000000,
      minimumInvestment: 1000000,
      maximumInvestment: 5000000,
      totalProjectCost: 150000000,
      equityRequired: 25000000,
      seniorDebt: 125000000,
      ltv: 83,
    },
    fees: {
      managementFee: 1.0,
      carriedInterest: 15,
      preferredReturn: 12,
    },
    projectedReturns: {
      targetIRR: 22,
      targetMultiple: 1.25,
      holdPeriod: "12 months",
      cashOnCash: 22,
    },
    risks: [
      "Oil price volatility during cargo transit",
      "Force majeure events (terminal shutdowns, piracy)",
      "Sanctions compliance complexity",
      "Counterparty risk on LC-issuing banks",
    ],
    naviInvolvement: {
      type: "Facilitation",
      amount: 0,
      role: "NAVI facilitated introduction, ongoing compliance monitoring",
    },
    timeline: {
      closeDate: "February 15, 2026",
      acquisitionDate: "March 1, 2026",
      firstDistribution: "Monthly",
    },
    documents: [
      { name: "Offtake Agreement", type: "pdf" },
      { name: "LC Documentation", type: "pdf" },
      { name: "Sanctions Compliance Report", type: "pdf" },
      { name: "Insurance Certificates", type: "pdf" },
    ],
    status: "closing_soon",
    softCommitments: 22000000,
    interestedParties: 4,
    assetClass: "Commodities",
    geography: "Nigeria / Europe",
  },
  {
    id: 5,
    title: "Miami Beach Hospitality",
    subtitle: "Boutique Hotel Acquisition & Renovation",
    sponsor: {
      name: "Isabella Rodriguez",
      title: "Founder, Luxe Hospitality Group",
      image: "/avraham-profile.png",
      track: "12 hotels, $400M AUM",
      verified: true,
    },
    thesis: `Luxe Hospitality has identified a distressed boutique hotel on Collins Avenue with exceptional repositioning potential. The 85-key property will undergo a $15M renovation to convert to a luxury lifestyle brand, targeting the growing experiential travel segment.

Key Investment Thesis:
• Acquiring at 40% below replacement cost
• Prime oceanfront location with limited new supply
• Post-renovation ADR target of $650 vs. current $280
• Strong operator track record in Miami market`,
    capitalStructure: {
      targetRaise: 18000000,
      minimumInvestment: 250000,
      maximumInvestment: 3000000,
      totalProjectCost: 55000000,
      equityRequired: 22000000,
      seniorDebt: 33000000,
      ltv: 60,
    },
    fees: {
      managementFee: 1.5,
      carriedInterest: 20,
      preferredReturn: 8,
    },
    projectedReturns: {
      targetIRR: 24,
      targetMultiple: 2.2,
      holdPeriod: "4-5 years",
      cashOnCash: 0,
    },
    risks: [
      "Construction/renovation cost overruns",
      "Hospitality market cyclicality",
      "Hurricane/climate risk",
      "Brand partnership execution",
    ],
    naviInvolvement: {
      type: "Co-Invest",
      amount: 1500000,
      role: "NAVI principals co-investing, design advisory",
    },
    timeline: {
      closeDate: "March 31, 2026",
      acquisitionDate: "April 15, 2026",
      firstDistribution: "Post-stabilization (2028)",
    },
    documents: [
      { name: "Investment Memorandum", type: "pdf" },
      { name: "Renovation Plans", type: "pdf" },
      { name: "Market Study", type: "pdf" },
      { name: "Proforma Financials", type: "xlsx" },
    ],
    status: "open",
    softCommitments: 9500000,
    interestedParties: 7,
    assetClass: "Real Estate",
    geography: "Miami Beach, FL",
  },
];

const DealCard = ({ deal, onIndicateInterest }: { deal: typeof curatedDeals[0], onIndicateInterest: () => void }) => {
  const [showDetails, setShowDetails] = useState(false);
  const progressPercent = (deal.softCommitments / deal.capitalStructure.targetRaise) * 100;

  const formatCurrency = (value: number) => {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="overflow-hidden border-border/50 hover:border-sky-500/30 transition-all duration-300">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <CardTitle className="text-xl">{deal.title}</CardTitle>
                {deal.status === "closing_soon" && (
                  <Badge variant="destructive" className="animate-pulse">Closing Soon</Badge>
                )}
              </div>
              <CardDescription className="text-base">{deal.subtitle}</CardDescription>
            </div>
            <Badge variant="outline" className="text-xs">
              {deal.assetClass}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Sponsor Section */}
          <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center overflow-hidden">
              <img 
                src={deal.sponsor.image} 
                alt={deal.sponsor.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.parentElement!.innerHTML = `<span class="text-xl font-bold text-white">${deal.sponsor.name.charAt(0)}</span>`;
                }}
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-semibold">{deal.sponsor.name}</span>
                {deal.sponsor.verified && (
                  <CheckCircle2 className="h-4 w-4 text-blue-500" />
                )}
              </div>
              <p className="text-sm text-muted-foreground">{deal.sponsor.title}</p>
              <p className="text-xs text-muted-foreground mt-1">{deal.sponsor.track}</p>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 rounded-lg bg-muted/30">
              <p className="text-2xl font-bold text-sky-500">{deal.projectedReturns.targetIRR}%</p>
              <p className="text-xs text-muted-foreground">Target IRR</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/30">
              <p className="text-2xl font-bold">{deal.projectedReturns.targetMultiple}x</p>
              <p className="text-xs text-muted-foreground">Target Multiple</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/30">
              <p className="text-2xl font-bold">{formatCurrency(deal.capitalStructure.minimumInvestment)}</p>
              <p className="text-xs text-muted-foreground">Minimum</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/30">
              <p className="text-2xl font-bold">{deal.projectedReturns.holdPeriod}</p>
              <p className="text-xs text-muted-foreground">Hold Period</p>
            </div>
          </div>

          {/* Funding Progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Soft Commitments</span>
              <span className="font-medium">{formatCurrency(deal.softCommitments)} / {formatCurrency(deal.capitalStructure.targetRaise)}</span>
            </div>
            <Progress value={progressPercent} className="h-2" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{deal.interestedParties} parties interested</span>
              <span>Closes {deal.timeline.closeDate}</span>
            </div>
          </div>

          {/* NAVI Involvement Badge */}
          <div className="p-3 rounded-lg bg-sky-500/10 border border-sky-500/20">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-sky-500" />
              <span className="text-sm font-medium text-sky-600">NAVI {deal.naviInvolvement.type}</span>
              {deal.naviInvolvement.amount > 0 && (
                <Badge variant="outline" className="ml-auto text-xs">
                  {formatCurrency(deal.naviInvolvement.amount)} committed
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">{deal.naviInvolvement.role}</p>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Dialog open={showDetails} onOpenChange={setShowDetails}>
              <DialogTrigger asChild>
                <Button variant="outline" className="flex-1 gap-2">
                  <Eye className="h-4 w-4" />
                  View Details
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-2xl">{deal.title}</DialogTitle>
                  <DialogDescription>{deal.subtitle}</DialogDescription>
                </DialogHeader>
                
                <div className="space-y-6 py-4">
                  {/* Thesis */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <FileText className="h-5 w-5 text-sky-500" />
                      Investment Thesis
                    </h3>
                    <div className="p-4 rounded-lg bg-muted/50 whitespace-pre-line text-sm">
                      {deal.thesis}
                    </div>
                  </div>

                  <Separator />

                  {/* Capital Structure */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <DollarSign className="h-5 w-5 text-sky-500" />
                      Capital Structure
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-sm text-muted-foreground">Target Raise</p>
                        <p className="text-xl font-bold">{formatCurrency(deal.capitalStructure.targetRaise)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-sm text-muted-foreground">Total Project Cost</p>
                        <p className="text-xl font-bold">{formatCurrency(deal.capitalStructure.totalProjectCost)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-sm text-muted-foreground">LTV</p>
                        <p className="text-xl font-bold">{deal.capitalStructure.ltv}%</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-sm text-muted-foreground">Min Investment</p>
                        <p className="text-xl font-bold">{formatCurrency(deal.capitalStructure.minimumInvestment)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-sm text-muted-foreground">Max Investment</p>
                        <p className="text-xl font-bold">{formatCurrency(deal.capitalStructure.maximumInvestment)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/30">
                        <p className="text-sm text-muted-foreground">Preferred Return</p>
                        <p className="text-xl font-bold">{deal.fees.preferredReturn}%</p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Risk Section */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-red-500" />
                      Risk Factors (Explicit)
                    </h3>
                    <div className="space-y-2">
                      {deal.risks.map((risk, index) => (
                        <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-red-500/5 border border-red-500/10">
                          <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{risk}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Documents */}
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <FileText className="h-5 w-5 text-sky-500" />
                      Deal Documents
                    </h3>
                    <div className="grid grid-cols-2 gap-3">
                      {deal.documents.map((doc, index) => (
                        <Button key={index} variant="outline" className="justify-start gap-2 h-auto py-3">
                          <Download className="h-4 w-4" />
                          <div className="text-left">
                            <p className="text-sm font-medium">{doc.name}</p>
                            <p className="text-xs text-muted-foreground uppercase">{doc.type}</p>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            
            <Button className="flex-1 gap-2 bg-sky-500 hover:bg-sky-600" onClick={onIndicateInterest}>
              <Heart className="h-4 w-4" />
              Indicate Interest
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function DealRoom() {
  const [showInterestDialog, setShowInterestDialog] = useState(false);
  const [selectedDeal, setSelectedDeal] = useState<typeof curatedDeals[0] | null>(null);
  const [interestAmount, setInterestAmount] = useState([500000]);
  const [notes, setNotes] = useState("");

  const handleIndicateInterest = (deal: typeof curatedDeals[0]) => {
    setSelectedDeal(deal);
    setInterestAmount([deal.capitalStructure.minimumInvestment]);
    setShowInterestDialog(true);
  };

  const submitInterest = () => {
    toast.success("Interest Indicated", {
      description: `Your interest of $${interestAmount[0].toLocaleString()} in ${selectedDeal?.title} has been recorded. Our team will reach out within 24 hours.`,
    });
    setShowInterestDialog(false);
    setNotes("");
  };

  const formatCurrency = (value: number) => {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value}`;
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 p-4 md:p-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-sky-500" />
            <Badge variant="outline" className="text-xs">Invite Only</Badge>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Curated Deal Room</h1>
          <p className="text-muted-foreground max-w-2xl">
            Vetted access to private deals, operators, and assets — with alignment, transparency, and cultural context. 
            No search. No feeds. Just curated opportunities.
          </p>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-sky-500">{curatedDeals.length}</p>
                <p className="text-sm text-muted-foreground">Live Opportunities</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold">$138M</p>
                <p className="text-sm text-muted-foreground">Total Deal Value</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold">$89.9M</p>
                <p className="text-sm text-muted-foreground">Soft Commitments</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold">37</p>
                <p className="text-sm text-muted-foreground">Interested Parties</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Deals Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {curatedDeals.map((deal) => (
            <DealCard 
              key={deal.id} 
              deal={deal} 
              onIndicateInterest={() => handleIndicateInterest(deal)}
            />
          ))}
        </div>

        {/* Interest Dialog */}
        <Dialog open={showInterestDialog} onOpenChange={setShowInterestDialog}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Indicate Interest</DialogTitle>
              <DialogDescription>
                This is a non-binding indication of interest. Our team will follow up to discuss next steps.
              </DialogDescription>
            </DialogHeader>
            
            {selectedDeal && (
              <div className="space-y-6 py-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <p className="font-semibold">{selectedDeal.title}</p>
                  <p className="text-sm text-muted-foreground">{selectedDeal.subtitle}</p>
                </div>

                <div className="space-y-4">
                  <Label>Investment Amount</Label>
                  <div className="space-y-4">
                    <Slider
                      value={interestAmount}
                      onValueChange={setInterestAmount}
                      min={selectedDeal.capitalStructure.minimumInvestment}
                      max={selectedDeal.capitalStructure.maximumInvestment}
                      step={50000}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        Min: {formatCurrency(selectedDeal.capitalStructure.minimumInvestment)}
                      </span>
                      <span className="text-2xl font-bold text-sky-500">
                        ${interestAmount[0].toLocaleString()}
                      </span>
                      <span className="text-muted-foreground">
                        Max: {formatCurrency(selectedDeal.capitalStructure.maximumInvestment)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Notes (Optional)</Label>
                  <Textarea
                    placeholder="Any questions or specific requirements..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={3}
                  />
                </div>

                <div className="p-3 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sm">
                  <p className="font-medium text-sky-600">Non-Binding Indication</p>
                  <p className="text-muted-foreground mt-1">
                    This does not constitute a commitment. Closing occurs off-platform with wire instructions provided separately.
                  </p>
                </div>

                <Button className="w-full bg-sky-500 hover:bg-sky-600" onClick={submitInterest}>
                  Submit Interest
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}

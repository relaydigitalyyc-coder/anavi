import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FolderLock, Clock, Shield, 
  Download, Eye, Lock, Settings, FileCheck
} from "lucide-react";
import { useLocation } from "wouter";

export default function DealRooms() {
  const [, setLocation] = useLocation();
  const { data: dealRooms, isLoading } = trpc.dealRoom.list.useQuery();

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "active": return "bg-sky-100 text-sky-700";
      case "pending_nda": return "bg-sky-100 text-sky-700";
      case "closed": return "bg-muted text-muted-foreground";
      case "archived": return "bg-slate-100 text-slate-700";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="p-8 space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-50 flex items-center justify-center">
              <FolderLock className="w-5 h-5 text-sky-600" />
            </div>
            Virtual Deal Rooms
          </h1>
          <p className="text-muted-foreground mt-2">
            Secure spaces for document sharing and deal execution
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <Card className="premium-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Total Rooms</div>
                <div className="text-3xl font-bold number-display">{dealRooms?.length || 0}</div>
              </div>
              <div className="w-12 h-12 rounded-xl bg-sky-50 flex items-center justify-center">
                <FolderLock className="w-6 h-6 text-sky-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="premium-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Active</div>
                <div className="text-3xl font-bold number-display text-sky-600">
                  {dealRooms?.filter(r => r.status === 'active').length || 0}
                </div>
              </div>
              <div className="w-12 h-12 rounded-xl bg-sky-50 flex items-center justify-center">
                <FileCheck className="w-6 h-6 text-sky-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="premium-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Pending NDA</div>
                <div className="text-3xl font-bold number-display text-sky-600">
                  {dealRooms?.filter(r => !r.status || r.status === null).length || 0}
                </div>
              </div>
              <div className="w-12 h-12 rounded-xl bg-sky-50 flex items-center justify-center">
                <Clock className="w-6 h-6 text-sky-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="premium-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-1">Closed</div>
                <div className="text-3xl font-bold number-display">
                  {dealRooms?.filter(r => r.status === 'closed').length || 0}
                </div>
              </div>
              <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
                <Lock className="w-6 h-6 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Deal Rooms List */}
      {isLoading ? (
        <div className="grid gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="premium-card">
              <CardContent className="p-6">
                <div className="h-32 animate-shimmer rounded-xl" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : !dealRooms || dealRooms.length === 0 ? (
        <Card className="premium-card">
          <CardContent className="p-16 text-center">
            <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
              <FolderLock className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No Deal Rooms Yet</h3>
            <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
              Deal rooms are created when you have mutual interest with a match
            </p>
            <Button onClick={() => setLocation("/matches")} className="btn-gold">
              View Matches
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {dealRooms.map((room, index) => {
            const settings = room.settings as any || {};
            
            return (
              <Card 
                key={room.id} 
                className="premium-card"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <Badge className={`${getStatusStyle(room.status || 'pending_nda')} border-0`}>
                          {(room.status || 'pending_nda').replace('_', ' ').toUpperCase()}
                        </Badge>
                        {settings.requireNda && (
                          <Badge variant="outline" className="text-muted-foreground">
                            <Lock className="w-3 h-3 mr-1" />
                            NDA Required
                          </Badge>
                        )}
                      </div>

                      <h3 className="text-xl font-semibold mb-3">{room.name}</h3>

                      {/* Room Features */}
                      <div className="flex flex-wrap gap-6 mt-4 text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Shield className="w-4 h-4" />
                          <span>Watermarked: <span className="font-medium text-foreground">{settings.watermarkDocuments ? 'Yes' : 'No'}</span></span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Download className="w-4 h-4" />
                          <span>Downloads: <span className="font-medium text-foreground">{settings.allowDownloads ? 'Allowed' : 'Restricted'}</span></span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          <span>Auto-expire: <span className="font-medium text-foreground">{settings.autoExpireAccess ? `${settings.expiryDays} days` : 'Never'}</span></span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span>Created {new Date(room.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2 lg:w-48">
                      <Button className="btn-gold">
                        <Eye className="w-4 h-4 mr-2" />
                        Enter Room
                      </Button>
                      <Button variant="outline" className="hover:border-primary hover:text-primary">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Security Notice */}
      <Card className="premium-card border-violet-200 bg-gradient-to-r from-violet-50 to-white">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-sky-100 flex items-center justify-center flex-shrink-0">
              <Shield className="w-6 h-6 text-sky-600" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Enterprise-Grade Security</h3>
              <p className="text-muted-foreground leading-relaxed">
                All deal rooms feature end-to-end encryption, dynamic watermarking, granular access controls, 
                and complete audit trails. Every document view, download, and action is logged for compliance.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Relationships from "./pages/Relationships";
import Intents from "./pages/Intents";
import Matches from "./pages/Matches";
import Deals from "./pages/Deals";
import DealRooms from "./pages/DealRooms";
import Compliance from "./pages/Compliance";
import Payouts from "./pages/Payouts";
import Network from "./pages/Network";
import Settings from "./pages/Settings";
import FamilyOffices from "./pages/FamilyOffices";
import Targeting from "./pages/Targeting";
import Calendar from "./pages/Calendar";
import Analytics from "./pages/Analytics";
import SPVGenerator from "./pages/SPVGenerator";
import LPPortal from "./pages/LPPortal";
import CapitalManagement from "./pages/CapitalManagement";
import AuditLogs from "./pages/AuditLogs";
import Commodities from "./pages/Commodities";
import RealEstate from "./pages/RealEstate";
import TransactionMatching from "./pages/TransactionMatching";
import TradingPlatform from "./pages/TradingPlatform";
import MemberOnboarding from "./pages/MemberOnboarding";
import FeeManagement from "./pages/FeeManagement";
import DealRoom from "./pages/DealRoom";
import Manifesto from "./pages/Manifesto";
import OperatorIntake from "./pages/OperatorIntake";
import KnowledgeGraphPage from "./pages/KnowledgeGraphPage";
import DealIntelligence from "./pages/DealIntelligence";
import CryptoAssets from "./pages/CryptoAssets";
import AIBrain from "./pages/AIBrain";
import Onboarding from "./pages/Onboarding";
import DashboardLayout from "./components/DashboardLayout";

// Public route wrapper - no auth required, just wraps in DashboardLayout
function PublicRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <DashboardLayout>
      <Component />
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/welcome" component={Onboarding} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/dashboard">
        <PublicRoute component={Dashboard} />
      </Route>
      <Route path="/relationships">
        <PublicRoute component={Relationships} />
      </Route>
      <Route path="/intents">
        <PublicRoute component={Intents} />
      </Route>
      <Route path="/matches">
        <PublicRoute component={Matches} />
      </Route>
      <Route path="/deals">
        <PublicRoute component={Deals} />
      </Route>
      <Route path="/deal-rooms">
        <PublicRoute component={DealRooms} />
      </Route>
      <Route path="/compliance">
        <PublicRoute component={Compliance} />
      </Route>
      <Route path="/payouts">
        <PublicRoute component={Payouts} />
      </Route>
      <Route path="/network">
        <PublicRoute component={Network} />
      </Route>
      <Route path="/settings">
        <PublicRoute component={Settings} />
      </Route>
      <Route path="/family-offices">
        <PublicRoute component={FamilyOffices} />
      </Route>
      <Route path="/targeting">
        <PublicRoute component={Targeting} />
      </Route>
      <Route path="/calendar">
        <PublicRoute component={Calendar} />
      </Route>
      <Route path="/analytics">
        <PublicRoute component={Analytics} />
      </Route>
      <Route path="/spv-generator">
        <PublicRoute component={SPVGenerator} />
      </Route>
      <Route path="/lp-portal">
        <PublicRoute component={LPPortal} />
      </Route>
      <Route path="/capital-management">
        <PublicRoute component={CapitalManagement} />
      </Route>
      <Route path="/audit-logs">
        <PublicRoute component={AuditLogs} />
      </Route>
      <Route path="/commodities">
        <PublicRoute component={Commodities} />
      </Route>
      <Route path="/real-estate">
        <PublicRoute component={RealEstate} />
      </Route>
      <Route path="/transaction-matching">
        <PublicRoute component={TransactionMatching} />
      </Route>
      <Route path="/trading">
        <PublicRoute component={TradingPlatform} />
      </Route>
      <Route path="/member-onboarding">
        <PublicRoute component={MemberOnboarding} />
      </Route>
      <Route path="/fee-management">
        <PublicRoute component={FeeManagement} />
      </Route>
      <Route path="/deal-room">
        <PublicRoute component={DealRoom} />
      </Route>
      <Route path="/manifesto">
        <PublicRoute component={Manifesto} />
      </Route>
      <Route path="/operator-intake">
        <PublicRoute component={OperatorIntake} />
      </Route>
      <Route path="/knowledge-graph">
        <PublicRoute component={KnowledgeGraphPage} />
      </Route>
      <Route path="/deal-intelligence">
        <PublicRoute component={DealIntelligence} />
      </Route>
      <Route path="/crypto-assets">
        <PublicRoute component={CryptoAssets} />
      </Route>
      <Route path="/ai-brain">
        <PublicRoute component={AIBrain} />
      </Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
